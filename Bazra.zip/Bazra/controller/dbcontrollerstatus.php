<?php

class dbcontroller {
   private $conn;
    function __construct() {
        
        include_once 'dbconnectstatus.php';
    
        $db=new dbconnectstatus();
        $this->conn=$db->connect();
}