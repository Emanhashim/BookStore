<?php

$error= "error";

        $db_host = "localhost";
        $db_username = "root";
        $db_pass = "";
        $db_name = "status";
       
$con = mysqli_connect($db_host,$db_username,$db_pass,$db_name) or die($error);

?>

