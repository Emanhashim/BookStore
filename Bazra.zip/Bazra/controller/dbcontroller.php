<?php

class dbcontroller {
   private $conn;
    function __construct() {
        
        include_once 'dbconnect.php';
    
        $db=new dbconnect();
        $this->conn=$db->connect();
}
public function login($username, $password){
        $pass=  md5($password);
        $stm=$this->conn->prepare("select * from account where username=? and password=?");
        $stm->bind_param("ss", $username, $pass);
        $stm->execute();
        $row = $stm->get_result();
          if($row->num_rows>0){
              return $row->fetch_assoc();
             
          }else {
              return -1;
    }
}

// this is for manager only
// public function login($username, $password){
//         $pass=  md5($password);
//         $stm=$this->conn->prepare("select * from account where username=? and password=?");
//         $stm->bind_param("ss", $username, $pass);
//         $stm->execute();
//         $row = $stm->get_result();
//           if($row->num_rows>0){
//               return $row->fetch_assoc();
             
//           }else {
//               return -1;
//     }
// }
public function getId($username, $password){
         $pass=  md5($password);
        $stm=$this->conn->prepare("select * from account where username=? and password=?");
        $stm->bind_param("ss", $username, $pass);
        $stm->execute();
        $row = $stm->get_result()->fetch_assoc();
        return $row['accountId'];
        
}
public function getPeperId($username, $password){
         $pass=  md5($password);
        $stm=$this->conn->prepare("select * from account where username=? and password=?");
        $stm->bind_param("ss", $username, $pass);
        $stm->execute();
        $row = $stm->get_result()->fetch_assoc();
        return $row['accountId'];
        
}
public function marketingsignup($firmname,$email,$location,$phone1,
        $phone2,$firstname,$lastname,$position,$address,$username,$password,$accId){
         $stm= $this->conn->prepare(" insert into marketing(firmname,email,location,phone1,
        phone2,firstname,lastname,position,address,username,password,accId) values(?,?,?,?,?,?,?,?,?,?,?,?);");
         $stm->bind_param("ssssssssssss",$firmname,$email,$location,$phone1,
        $phone2,$firstname,$lastname,$position,$address,$username,$password,$accId);
         if($stm->execute()){
             return 1;
             
         }else{
             return 2;
         }
          
        }
         public function addmarketing_pass($username,$password){
             $pass=  md5($password);
         $stm= $this->conn->prepare("insert into account(username,password,role) values(?,?,'marketing');");
         $stm->bind_param("ss",$username,$pass);
         if($stm->execute()){
             return 1;
             
         }else{
             return 2;
         }
          
        }
public function ITsignup($firmname,$email,$location,$phone1,
        $phone2,$firstname,$lastname,$position,$address,$username,$password,$accId){
         $stm= $this->conn->prepare(" insert into it(firmname,email,location,phone1,
        phone2,firstname,lastname,position,address,username,password,accId) values(?,?,?,?,?,?,?,?,?,?,?,?);");
         $stm->bind_param("ssssssssssss",$firmname,$email,$location,$phone1,
        $phone2,$firstname,$lastname,$position,$address,$username,$password,$accId);
         if($stm->execute()){
             return 1;
             
         }else{
             return 2;
         }
          
        }
        public function addIT_pass($username,$password){
             $pass=md5($password);
         $stm= $this->conn->prepare("insert into account(username,password,role) values(?,?,'It department');");
         $stm->bind_param("ss",$username,$pass);
         if($stm->execute()){
             return 1;
             
         }else{
             return 2;
         }
          
        }
        // thiswas accountant pw
        public function Iesignup($firmname,$email,$location,$phone1,
        $phone2,$firstname,$lastname,$position,$address,$username,$password,$accId){
         $stm= $this->conn->prepare(" insert into ie(firmname,email,location,phone1,
        phone2,firstname,lastname,position,address,username,password,accId) values(?,?,?,?,?,?,?,?,?,?,?,?);");
         $stm->bind_param("ssssssssssss",$firmname,$email,$location,$phone1,
        $phone2,$firstname,$lastname,$position,$address,$username,$password,$accId);
         if($stm->execute()){
             return 1;
             
         }else{
             return 2;
         }
          
        }
        public function Ie_pass($username,$password){
            $pass=md5($password); 
         $stm= $this->conn->prepare("insert into account(username,password,role) values(?,?,'Import Export');");
         $stm->bind_param("ss",$username,$pass);
         if($stm->execute()){
             return 1;
             
         }else{
             return 2;
         }
          
        }
      
        public function adminsignup($firmname,$email,$location,$phone1,
        $phone2,$firstname,$lastname,$position,$address,$username,$password,$accId){
         $stm= $this->conn->prepare(" insert into adminstrator(firmname,email,location,phone1,
        phone2,firstname,lastname,position,address,username,password,accId) values(?,?,?,?,?,?,?,?,?,?,?,?);");
         $stm->bind_param("ssssssssssss",$firmname,$email,$location,$phone1,
        $phone2,$firstname,$lastname,$position,$address,$username,$password,$accId);
         if($stm->execute()){
             return 1;
            
         }else{
             return 2;
         }
          
        }
         public function admin_pass($username,$password){
              $pass=md5($password);
         $stm= $this->conn->prepare("insert into account(username,password,role) values(?,?,'admin');");
         $stm->bind_param("ss",$username,$pass);
         if($stm->execute()){
             return 1;
             
         }else{
             return 2;
         }
          
        }
        
        //
        public function motorsignup($firmname,$email,$location,$phone1,
        $phone2,$firstname,$lastname,$position,$address,$username,$password,$accId){
         $stm= $this->conn->prepare(" insert into motor(firmname,email,location,phone1,
        phone2,firstname,lastname,position,address,username,password,accId) values(?,?,?,?,?,?,?,?,?,?,?,?);");
         $stm->bind_param("ssssssssssss",$firmname,$email,$location,$phone1,
        $phone2,$firstname,$lastname,$position,$address,$username,$password,$accId);
         if($stm->execute()){
             return 1;
             
         }else{
             return 2;
         }
          
        }
        public function addmotor_pass($username,$password){
             $pass=md5($password);
         $stm= $this->conn->prepare("insert into account(username,password,role) values(?,?,'motor department');");
         $stm->bind_param("ss",$username,$pass);
         if($stm->execute()){
             return 1;
             
         }else{
             return 2;
         }
          
        }
        
        //
          public function accountantsignup($firmname,$email,$location,$phone1,
        $phone2,$firstname,$lastname,$position,$address,$username,$password,$accId){
         $stm= $this->conn->prepare(" insert into ie(firmname,email,location,phone1,
        phone2,firstname,lastname,position,address,username,password,accId) values(?,?,?,?,?,?,?,?,?,?,?,?);");
         $stm->bind_param("ssssssssssss",$firmname,$email,$location,$phone1,
        $phone2,$firstname,$lastname,$position,$address,$username,$password,$accId);
         if($stm->execute()){
             return 1;
             
         }else{
             return 2;
         }
          
        }
        public function accountant_pass($username,$password){
             $pass=md5($password);
         $stm= $this->conn->prepare("insert into account(username,password,role) values(?,?,'Import Export');");
         $stm->bind_param("ss",$username,$pass);
         if($stm->execute()){
             return 1;
             
         }else{
             return 2;
         }
          
        }
        
         public function updatepass($user,$newpass){
              $pass=md5($newpass);
                $stm=$this->conn->prepare("update account set password=? where username=? ");
                $stm->bind_param("ss",$pass,$user);
         if($stm->execute()){
                    return 1;
                }else{
                    return 2;
                }
        
             }
}

?>