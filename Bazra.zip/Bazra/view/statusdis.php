<?php
    $active = "statusdis.php";
    include_once './template/header.php';
 ?>  <?php

include ('../controller/dbs.php');  
if(isset($_GET['search']) && $_GET['search']==""){
    $sql= "SELECT * FROM payments";
}
if(isset($_GET['search'])){
    $sql= "SELECT * FROM payments WHERE title like '%$_GET[search]%'";
}else{
    $sql= "SELECT * FROM payments";
}


$res= mysqli_query($con,$sql);

?>



<?php

while ($row = mysqli_fetch_array($res)){
    $id=$row['paymentsid'];
    
    $paymentissue=$row['paymentissue'];
    
   
      $price=$row['price'];
    
     
       $pdate=$row['pdate'];
  
    
    
//    echo $id. "" . $name . "<a href='download.php?dow=$path'>Download</a><br>";
?>



<table id="dtBasicExample" class="table table-striped table-bordered" cellspacing="0" width="100%">
  <!-- <thead>
    <tr>
      <th class="th-sm">Payment Issue
      </th>
      <th class="th-sm">Price
      </th>
      <th class="th-sm">Payment Date
      </th>
     
    </tr>
  </thead> -->

  <?php
  echo '
  <thead>
  <tbody>
    <tr>
    <tr>
      <th class="th-sm">Payment Issue
      </th>
      <th class="th-sm">Price
      </th>
      <th class="th-sm">Payment Date
      </th>
     
    </tr>
  </thead>
 
                        ';
     
                        
    
                                      
     echo'  <td> ' .$paymentissue.' </td>';
      echo' <td> ' .$price. '</td>';
     echo' <td> '.$pdate.' </td> ';
     echo'
      
    </tr>
    </th>
    </tbody>
  </tfoot>
  </table>

   ';

     
}
?>
<script>
$(document).ready(function () {
$('#dtBasicExample').DataTable();
$('.dataTables_length').addClass('bs-select');
});
</script>
    
   