<?php
    $active = "IE";
    include_once './template/header.php';
 ?>  <?php

include ('../controller/db.php');  
if(isset($_GET['search']) && $_GET['search']==""){
    $sql= "SELECT * FROM iedoc";
}
if(isset($_GET['search'])){
    $sql= "SELECT * FROM iedoc WHERE title like '%$_GET[search]%'";
}else{
    $sql= "SELECT * FROM iedoc";
}


$res= mysqli_query($con,$sql);

?>


<div class="container d-flex justify-content-end mt-3">
    <form class="form-inline" style="width: 400px;  margin-left: 10px; margin-right: 20px; margin-top: 20px;" method="GET" action="iedis.php">
        <i class="fas fa-search" aria-hidden="true"></i>
        <input name="search" class="form-control form-control-sm ml-3 w-75" type="text" placeholder="Search"
          aria-label="Search">
      </form>
</div>
<?php

while ($row = mysqli_fetch_array($res)){
    $id=$row['iepaper'];
    
    $name=$row['title'];
    
   
      $description=$row['description'];
      $type=$row['type'];
      $status=$row['status'];
    
     
       $published=$row['published'];
    $path= $row['path'];
    
    
//    echo $id. "" . $name . "<a href='download.php?dow=$path'>Download</a><br>";
?>

        <?php
echo '
    <div class="d-flex justify-content-center">
    <div class="media" style="margin:50px; ">
 
  <div class="media-body" style="margin-left:10px;">';

    echo '<h3>Title : '.$name.'</h5>';
       
          echo '<h5> Abstract</h5>';
         echo '<p style="width:500px;">'.$description.'</p>';
         echo '<h5> Project Type :'.$type.'</p>';
         echo '<h5> Current Status :'.$status.'</p>';
         
         echo '<h5> Published date : '.$published.'</h5>';
        echo "<a href='iedownload.php?id=".$id."'>Download</a>";
         
        echo '<hr>';
 echo' </div>
</div>
</div>

';
      // echo '<img src="'.$picpath.'" width="60" height="70" alt="cover"/>';
    
       
       
    //echo $id. "" . $name . $picpath. "<a href='download.php?id=".$id."'>Download</a><br>";
    
 

}
?>


            


<!--</div>-->
<?php 
 include_once './template/footer.php';
?>
             
       