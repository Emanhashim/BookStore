
<footer class="white-text py-5 mt-3 heavy-rain-gradient">

  <!-- Copyright -->
  <div class="footer-copyright text-center lighten-5 py-3" height="100%" width="100%">© 2021 Copyright:
      <a href="../MDB-Free_4.8.2/home.php" class="white-text"> Bazra Motor</a>
  </div>
  <!-- Copyright -->

</footer>
      
<!-- Footer -->
         <!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
    </body>
</html>
