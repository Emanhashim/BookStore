<?php
 $active = "status.php";
include_once './template/header.php';
?>


<?php
       $active = "status";
       include_once './template/header.php';
      
       $accountId=$_SESSION['accountId'];
       if($accountId==''){
            header("Location: landing.php");
       }
       
        ?>   
         

        <div class="upload">
         <div class="d-flex justify-content-center"> 
             
             
             
       <!-- Default form contact -->
       <form class="text-center border border-light p-5" style="background-color: white;" action="status.php" method="post" enctype="multipart/form-data">

    <p class="h4 mb-4 amber-text">Insert File </p>

    <!-- Name -->
   

  
    <!-- department -->
    <!--<label>Department</label>-->
    <select class="browser-default custom-select mb-4" name="dept" required>
         <option value="0">Payment Issue</option>
        <option value="House Rent"> House Rent</option>
        <option value="Water">Water</option>
        <option value="Electricity">Electricity</option>
        <option value="Wifi">Wifi</option>
        <option value="other">Other</option>
    </select>

  
  <!-- Email -->
  <input type="number" id="defaultContactFormPrice" class="form-control mb-4" placeholder="Price" name="price" required>


    <div class="md-form">
    <br>
        <input placeholder="Published Date" type="date" id="date-picker-example" class="form-control datepicker" name="pdate" required>
        
        <label for="date-picker-example" style="margin-top: 15px;"><h5><center>Choose Published date</center></h5>
  </label>
  </div>

  
 
<br>

<button class="btn btn-warning-white" style="margin-top: 30px; background-color: #ffc107;"type="submit" name="submit">Insert File
               </button>
               <button id="modal" class="btn btn-outline-amber d-none" data-toggle="modal" data-target="#basicExampleModal">
                 Model
               </button></button>
</form>
</div>
</div>
       
       <?php

include ('../controller/dbs.php');  

if(isset($_POST['submit'])){
    
    $dept=$_POST['dept'];
   
    $price=$_POST['price'];
    $pdate=$_POST['pdate'];
     
    
   
    
    if( $dept  && $price &&  $pdate ){
        
 
        
       // $query=  mysqli_query($con,"INSERT INTO documents (title,path,dept,desciption,price,published) values ('$doc_name','$location','$dept','$desc','$price','$pdate')");
$query=  mysqli_query($con,"INSERT INTO  payments(paymentissue,price,pdate) values ('$dept','$price','$pdate')");
                
//header('Location:index.php');
echo '
        
<div class="modal fade" id="basicExampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
aria-hidden="true">
<div class="modal-dialog" role="document">
 <div class="modal-content">
   <div class="modal-header">
     <h5 class="modal-title" id="exampleModalLabel">Bazra Motors</h5>
     <button type="button" class="close" data-dismiss="modal" aria-label="Close">
       <span aria-hidden="true">&times;</span>
     </button>
   </div>
   <div class="modal-body">
    Succesfully Insereted
   </div>
  
 </div>
</div>
</div>


';



}
}
else{
die("Please select a file");
}

?>
<!--<form action="upload.php" method="post" enctype="multipart/form-data">
<label>Document Name</label>
<input type="text" name="doc_name">
<input type="file" name="myfile">
<input type="submit" name="submit" value="Upload">

</form>-->

<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="js/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="js/mdb.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
  $('#modal').click();
});


</script>

          <?php
       include_once './template/footer.php';
        ?> 
       









   