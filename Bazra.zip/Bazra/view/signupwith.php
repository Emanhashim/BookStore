<html>
    <head>
      <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Bazra Motors</title>
   <link rel="icon" type="image/png" href="bazraa.jpg"/>
   <!--Font Awesome--> 
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css"> 
   <!--Bootstrap core CSS--> 
  <link href="css/bootstrap.min.css" rel="stylesheet">
   <!--Material Design Bootstrap--> 
  <link href="css/mdb.min.css" rel="stylesheet">
   <!--Your custom styles (optional)--> 
  <link href="css/style.css" rel="stylesheet">
  
  
  
  <style>
      body{
          background-color: whitesmoke;
      }
      .with{
          widith:200px;
          height:200px;
          padding-top: 150px;
          margin-left: 400px;
      }
      a{
          color: black;
      }

a:hover {
    color: #ffc107; 
}

/* selected link */
a:active {
    color: gray;
}
  </style>
    </head>
    <div class="with">
<div class="container">
<div class="media">
    <img class="d-flex mr-3"  width="75px" height="75px"src="universityimage.png" alt="Generic placeholder image">
  <div class="media-body">
      <h5 class="mt-0 font-weight-bold"><a href="./IE.php"><u>Import and Export</u></a></h5>
                Technology or Product developers,Specialist, Government in scientific roles
  </div>
</div>
    </br>
  <div class="media">
      <img class="d-flex mr-3" width="75px" height="75px" src="userimage.png" alt="Generic placeholder image">
  <div class="media-body">
      <h5 class="mt-0 font-weight-bold"><a href="./marketing.php"><u>Marketing</u></a></h5>
                 view, comment, or suggest
  </div>
  </div>
    </br>
  <div class="media">
      <img class="d-flex mr-3" width="75px" height="75px" src="resercherimage.jpg" alt="Generic placeholder image">
  <div class="media-body">
      <h5 class="mt-0 font-weight-bold"><a href="./motor.php"><u>Bazra Motors</u></a></h5>
                       Student, personal data analyst
  </div>
  </div>
    <br>
  <div class="media">
      <img class="d-flex mr-3"  width="75px" height="75px"src="universityimage.png" alt="Generic placeholder image">
  <div class="media-body">
      <h5 class="mt-0 font-weight-bold"><a href="./IT.php"><u>IT Department</u></a></h5>
                Governmental universities
  </div>
  </div>
    </br>
    <div class="media">
      <img class="d-flex mr-3"  width="75px" height="75px"src="universityimage.png" alt="Generic placeholder image">
  <div class="media-body">
      <h5 class="mt-0 font-weight-bold"><a href="./adminsign.php"><u>ADMIN</u></a></h5>
                Governmental universities
  </div>
  </div>
 
  </div>
</div>
  
  
  
  
  <script type="text/javascript" src="js/universitygrantjs.js"></script>
  <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
<!--   Bootstrap tooltips 
  <script type="text/javascript" src="js/popper.min.js"></script>
   <!--Bootstrap core JavaScript--> 
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
   <!--MDB core JavaScript--> 
  <script type="text/javascript" src="js/mdb.min.js"></script>
    </body>
</html>