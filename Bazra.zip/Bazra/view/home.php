 <?php
     $active = "home";
       include_once './template/header.php';
        ?> 




<?php
        include_once './template/footer.php';
        ?>