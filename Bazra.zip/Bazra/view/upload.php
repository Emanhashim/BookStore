     <?php
       $active = "upload";
       include_once './template/header.php';
      
       $accountId=$_SESSION['accountId'];
       if($accountId==''){
            header("Location: landing.php");
       }
       
        ?>   
         

        <div class="upload">
         <div class="d-flex justify-content-center"> 
             
             
             
       <!-- Default form contact -->
       <form class="text-center border border-light p-5" style="background-color: white;" action="upload.php" method="post" enctype="multipart/form-data">

    <p class="h4 mb-4 amber-text">Share File Here</p>

    <!-- Name -->
    <input type="text" id="defaultContactFormTitle" class="form-control mb-4" placeholder="Title" name="title" required>

  
    <!-- department -->
    <!--<label>Department</label>-->
    

    <!-- Message -->
    <!--<label>Description</label>-->
    <div class="form-group">
        <textarea class="form-control rounded-0" id="exampleFormControlTextarea2" required rows="3" placeholder="Abstract" name="abs"></textarea>
    </div>
  <!-- Email -->
  


    <div class="md-form">
        <input placeholder="Published Date" type="date" id="date-picker-example" class="form-control datepicker" name="pdate" required>
        <label for="date-picker-example" style="margin-top: 15px;"><h5><center>Choose Published date</center></h5>
  </label>
</div>

  <div class="custom-file">
    <input type="file" class="custom-file-input" id="inputGroupFile01"
      aria-describedby="inputGroupFileAddon01" name="myfile">
    <label class="custom-file-label" for="inputGroupFile01" required>Choose file</label>
  </div>

 
<br>
<button class="btn btn-warning-white" style="margin-top: 30px; background-color: #ffc107;"type="submit" name="submit"><b>Upload</b></button>
</form>
</div>
</div>
       
       <?php

include ('../controller/db.php');  

if(isset($_POST['submit'])){
    $title=$_POST['title'];
    $abs=$_POST['abs'];
    $pdate=$_POST['pdate'];
    
    $name=$_FILES['myfile']['name'];
    $tmp_name=$_FILES['myfile']['tmp_name'];
    
   
    
    if($name &&  $title &&   $abs &&   $pdate ){
        
        $location="doc/$name";
         
         
        if($_FILES['myfile']['error']>0){
            echo 'file too large';
        }
        
//        if($_FILES['myfile']['size']< 25000){
//            
//            echo "file size exceddes";
//        }
        
        
        else{
        move_uploaded_file($tmp_name, $location);
        
        
       // $query=  mysqli_query($con,"INSERT INTO documents (title,path,dept,desciption,price,published) values ('$doc_name','$location','$dept','$desc','$price','$pdate')");
$query=  mysqli_query($con,"INSERT INTO documents (path,title,description,published,accId) values ('$location','$title','$abs','$pdate','$accountId')");
                
//header('Location:index.php');
        echo 'Sucessfully Uploaded';
       
       
      
        }
    }
    else{
        die("Please select a file");
    }
}
?>

 

          <?php
       include_once './template/footer.php';
        ?> 
       