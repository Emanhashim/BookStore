<?php
       $active = "motorupload";
       include_once './template/header.php';
      
//       $accountId=$_SESSION['accountId'];
//       if($accountId==''){
//            header("Location: landing.php");
//       }
       
        ?>   
         

        <div class="upload">
         <div class="d-flex justify-content-center"> 
             
             
             
       <!-- Default form contact -->
       <form class="text-center border border-light p-5" style="background-color: white;" action="motorupload.php" method="post" enctype="multipart/form-data">

    <p class="h4 mb-4 amber-text">Post File Here</p>

    <!-- Name -->
    <input type="text" id="defaultContactFormTitle" class="form-control mb-4" placeholder="Title" name="doc_name" required>

  
    
    <div class="form-group">
        <textarea class="form-control rounded-0" id="exampleFormControlTextarea2" required rows="3" placeholder="Abstract" name="desc"></textarea>
    </div>
    <br>
    <input type="text" id="defaultContactFormTitle" class="form-control mb-4" placeholder="Project type" name="type" required>
  <br/>
  <select class="browser-default custom-select mb-4" name="status" required>
         <option value="0">Project Status</option>
        <option value="beginning"> Beginning</option>
        <option value="pending">Pendiing</option>
        <option value="finished">finished</option>
        
    </select>
    <br>


    <div class="md-form">
        <input placeholder="Published Date" type="date" id="date-picker-example" class="form-control datepicker" name="pdate" required>
        <label for="date--example" style="margin-top: 15px;"><h5><center>Choose Published date</center></h5>
  </label>
</div>

<div class="custom-file">
    <input type="file" class="custom-file-input" id="inputGroupFile01"
      aria-describedby="inputGroupFileAddon01" name="myfile">
    <label class="custom-file-label" for="inputGroupFile01" required>Choose file</label>
  </div>


  

<button class="btn btn-warning-white" style="margin-top: 30px; background-color: #ffc107;"type="submit" name="submit">  Upload
               </button>
               <button id="modal" class="btn btn-outline-amber d-none" data-toggle="modal" data-target="#basicExampleModal">
                 Model
               </button></button>
</form>
</div>
</div>
       
       <?php

include ('../controller/db.php');  

if(isset($_POST['submit'])){
    $doc_name=$_POST['doc_name'];
   
    $desc=$_POST['desc'];
    $type=$_POST['type'];
    $status=$_POST['status'];
   
    $pdate=$_POST['pdate'];
     
    
    $name=$_FILES['myfile']['name'];
    $tmp_name=$_FILES['myfile']['tmp_name'];
    
    
    
    if(  $doc_name &&  $desc && $type && $status && $pdate && $name  ){
        
        $location="doc/$name";
         
         
        if($_FILES['myfile']['error']>0){
            echo 'file too large';
        }
        
//        if($_FILES['myfile']['size']< 25000){
//            
//            echo "file size exceddes";
//        }
        
        
        else{
        move_uploaded_file($tmp_name, $location);
       
        
       // $query=  mysqli_query($con,"INSERT INTO documents (title,path,dept,desciption,price,published) values ('$doc_name','$location','$dept','$desc','$price','$pdate')");
$query=  mysqli_query($con,"INSERT INTO motordoc (path,title,description,type, status, published) values ('$location','$doc_name','$desc','$type','$status','$pdate')");
                
//header('Location:index.php');
        // echo 'Sucessfully Uploaded';
       echo '<div class="modal fade" id="basicExampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
       aria-hidden="true">
       <div class="modal-dialog" role="document">
         <div class="modal-content">
           <div class="modal-header">
             <h5 class="modal-title" id="exampleModalLabel">Bazra Motors</h5>
             <button type="button" class="close" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">&times;</span>
             </button>
           </div>
           <div class="modal-body">
            Succesfully Uploaded
           </div>
          
         </div>
       </div>
     </div>
     ';
       
      
        }
    }
    else{
        die("Please select a file");
    }
}
?>
<!--<form action="upload.php" method="post" enctype="multipart/form-data">
    <label>Document Name</label>
    <input type="text" name="doc_name">
    <input type="file" name="myfile">
    <input type="submit" name="submit" value="Upload">
    
</form>-->
 
<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
  
  <script type="text/javascript">
      $(document).ready(function(){
          $('#modal').click();
       });
  
  
  </script>



          <?php
       include_once './template/footer.php';
        ?> 
       