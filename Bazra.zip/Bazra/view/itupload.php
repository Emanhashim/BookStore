     <?php
       $active = "itupload";
       include_once './template/header.php';
      
//       $accountId=$_SESSION['accountId'];
//       if($accountId==''){
//            header("Location: landing.php");
//       }
       
        ?>   
         

        <div class="upload">
         <div class="d-flex justify-content-center"> 
             
             
             
       <!-- Default form contact -->
       <form class="text-center border border-light p-5" style="background-color: white;" action="itupload.php" method="post" enctype="multipart/form-data">

    <p class="h4 mb-4 amber-text">Share File Here</p>

    <!-- Name -->
    <input type="text" id="defaultContactFormTitle" class="form-control mb-4" placeholder="Title" name="title" required>

  
    <!-- department -->
    <!--<label>Department</label>-->
    

    <!-- Message -->
    <!--<label>Description</label>-->
    <div class="form-group">
        <textarea class="form-control rounded-0" id="exampleFormControlTextarea2" required rows="3" placeholder="Abstract" name="abs"></textarea>
    </div>
    <br>
    <input type="text" id="defaultContactFormTitle" class="form-control mb-4" placeholder="Project type" name="type" required>
  <br/>
  <select class="browser-default custom-select mb-4" name="status" required>
         <option value="0">Project Status</option>
        <option value="beginning"> Beginning</option>
        <option value="pending">Pendiing</option>
        <option value="finished">finished</option>
        
    </select>
    <br>
  


    <div class="md-form">
        <input placeholder="Published Date" type="date" id="date-picker-example" class="form-control datepicker" name="pdate" required>
        <label for="date-picker-example" style="margin-top: 15px;"><h5><center>Choose Published date</center></h5>
  </label>
</div>

  <div class="custom-file">
    <input type="file" class="custom-file-input" id="inputGroupFile01"
      aria-describedby="inputGroupFileAddon01" name="myfile">
    <label class="custom-file-label" for="inputGroupFile01" required>Choose file</label>
  </div>

 
<br>
<button class="btn btn-warning-white" style="margin-top: 30px; background-color: #ffc107;"type="submit" name="submit">Upload
               </button>
               <button id="modal" class="btn btn-outline-amber d-none" data-toggle="modal" data-target="#basicExampleModal">
                 Model
               </button></button>
</form>
</div>
</div>
       
       <?php

include ('../controller/db.php');  

if(isset($_POST['submit'])){
    $title=$_POST['title'];
    $abs=$_POST['abs'];
    $type=$_POST['type'];
    $status=$_POST['status'];
    $pdate=$_POST['pdate'];
    
    $name=$_FILES['myfile']['name'];
    $tmp_name=$_FILES['myfile']['tmp_name'];
    
   
    
    if($name &&  $title &&   $abs && $type && $status &&  $pdate ){
        
        $location="doc/$name";
         
         
        if($_FILES['myfile']['error']>0){
            echo 'file too large';
        }
        
//        if($_FILES['myfile']['size']< 25000){
//            
//            echo "file size exceddes";
//        }
        
        
        else{
        move_uploaded_file($tmp_name, $location);
        
        
       // $query=  mysqli_query($con,"INSERT INTO documents (title,path,dept,desciption,price,published) values ('$doc_name','$location','$dept','$desc','$price','$pdate')");
$query=  mysqli_query($con,"INSERT INTO itdoc (path,title,description,type, status, published) values ('$location','$title','$abs','$type', '$status','$pdate')");
                
//header('Location:index.php');
        echo '
        <div class="modal fade" id="basicExampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
       aria-hidden="true">
       <div class="modal-dialog" role="document">
         <div class="modal-content">
           <div class="modal-header">
             <h5 class="modal-title" id="exampleModalLabel">Bazra Motors</h5>
             <button type="button" class="close" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">&times;</span>
             </button>
           </div>
           <div class="modal-body">
            Succesfully Uploaded
           </div>
          
         </div>
       </div>
     </div>
        
        
        ';
       
       
      
        }
    }
    else{
        die("Please select a file");
    }
}
?>
<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
  
  <script type="text/javascript">
      $(document).ready(function(){
          $('#modal').click();
       });
  
  
  </script>
 

          <?php
       include_once './template/footer.php';
        ?> 
       